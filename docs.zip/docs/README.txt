Khlosh 0.1.0 — A premium macOS terminal
========================================

Files in this release:

  Khlosh-0.1.0-arm64.dmg   Apple Silicon (M1 / M2 / M3 / M4)   93 MB
  Khlosh-0.1.0-x64.dmg     Intel Macs                          98 MB
  SHA256SUMS.txt           Checksums for verification


Install
-------

1. Download the DMG matching your Mac's architecture.
   - Apple silicon (M-series): use the `arm64` file
   - Intel: use the `x64` file
2. Double-click the DMG to mount it.
3. Drag `Khlosh.app` onto the `Applications` shortcut.
4. Eject the DMG.


First launch
------------

Khlosh is not yet code-signed with an Apple Developer ID, so on first
launch macOS Gatekeeper will say:

    "Khlosh.app cannot be opened because Apple cannot check it
     for malicious software."

To bypass this safely:

  • Right-click `Khlosh.app` in Applications → click "Open"
  • Click "Open" again in the confirmation dialog

You only need to do this once. After that, Khlosh launches normally
from Spotlight or the Dock.


Verify download integrity
-------------------------

  shasum -a 256 -c SHA256SUMS.txt

Both files should report `OK`.


Known limitations
-----------------

  • Not code-signed (Gatekeeper warning on first launch — see above)
  • Not notarized
  • macOS only (no Windows or Linux builds)
  • Requires macOS 10.12+ (uses APFS disk image)


Build info
----------

  Electron 29.4.6
  node-pty 1.1.0 (rebuilt for both architectures)
  WebGL renderer (xterm.js) for the terminal pane
